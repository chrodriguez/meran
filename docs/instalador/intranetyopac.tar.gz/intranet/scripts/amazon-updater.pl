#!/usr/bin/perl

use C4::AR::Amazon;

getAllImages();