package My::DB::Object;

use base qw(Rose::DB::Object);

1;
