use strict;
require Exporter;
use C4::Context;
use CGI;
use C4::AR::CacheMeran;
use vars qw($CACHE_MERAN);
$CACHE_MERAN= C4::AR::CacheMeran->new();
1;
