var month_names = ['Jan','Feb','M�rz','Apr','Mai','Jun','Jul','Aug','Sept','Okt','Nov','Dez'];
var date_format = '%d.%m.%Y';
// var date_format = '%Y/%m/%d';