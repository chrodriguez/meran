package My::Auto::Color;
use strict;
use base 'My::Object';
__PACKAGE__->meta->auto_initialize;
1;
