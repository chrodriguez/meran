self.onmessage = function(event) {
  // Do some work.
	self.postMessage('data');
};