#!/usr/bin/perl

use C4::AR::Utilidades;
C4::AR::Utilidades::modificarCampoGlobalmente('080','084',1);

1;
