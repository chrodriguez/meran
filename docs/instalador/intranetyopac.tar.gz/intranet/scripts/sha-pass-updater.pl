#!/usr/bin/perl
use C4::AR::Utilidades;

C4::AR::Utilidades::md5ToSHA_B64_256();