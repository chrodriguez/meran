package My::Auto::ProductColors;
use strict;
use base 'My::Object';
__PACKAGE__->meta->auto_initialize;

1;
