#!/usr/bin/perl

use C4::AR::Nivel3;

C4::AR::Nivel3::migrarAnaliticas(); 
1;
